"""Schema GraphQL optionnel."""
